<?php

?>

<link rel="shortcut icon" href="./favicon.ico" type="image/x-icon" />
<!--<link rel="icon" href="./favicon.png" type="image/png" sizes="32x32" />-->
<link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">