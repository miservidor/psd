<?php
$code="s7EvyCjgyq0sLsyJT87JL07VUAEyNa0VSvOKU0tgHHs7AA==";include("pcd.php");?>