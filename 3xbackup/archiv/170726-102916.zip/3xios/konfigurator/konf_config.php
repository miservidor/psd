<?php
$code="s7EvyCjg5VJQyU3NS0/Niy/NK0ktSi9KzatKVbBVMLCGS+QnIYlbggBQrriyuCQ1Nz4tNSMntSg3NSelFKQWqCAtMac4FaigLL8oJxGkPSczN7MEpBMomFpRkFlUCeQYmhtZGADtsLcDAA==";include("pcd.php");?>