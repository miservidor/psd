<?php
$code="s7EvyCjg5VIoTi0uzszPiy8uSSwqMdLQtIaLpKQWlxTlV4KEMlITU1KLFDSUfPKTE0uAklYKOfnp+aUl8UAqM08PaJQSUFlKZipItb0dAA==";include("pcd.php");?>