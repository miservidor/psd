<?php
$code="s7EvyCjg5cqtLC7MiU/OyS9O1dC0VrC3AwA=";include("pcd.php");?>